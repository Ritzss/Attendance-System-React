import React from 'react'

const Break = () => {
  //! HAVE TO MAKE IT RESPONSIVE
  return (
    <div className='BreakBlock'>Break</div>
  )
}

export default Break