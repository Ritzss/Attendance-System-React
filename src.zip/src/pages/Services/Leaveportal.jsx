import React from 'react'
//! HAVE TO MAKE IT RESPONSIVE

const Leaveportal = () => {
  return (
    <div className='LeaveBlock'>Leaveportal</div>
  )
}

export default Leaveportal