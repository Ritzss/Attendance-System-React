import React from 'react'
import Navbar from '../../components/Navbar/Navbar'
//! HAVE TO MAKE IT RESPONSIVE

const ResetPassword = () => {
  return (
    <section className='ResetBlock'>
        <Navbar />
        
    </section>
  )
}

export default ResetPassword