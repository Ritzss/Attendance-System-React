import React from 'react'

//! HAVE TO MAKE IT RESPONSIVE

const Holiday = () => {
  return (
    <div className='HolidayBlock'>Holiday</div>
  )
}

export default Holiday