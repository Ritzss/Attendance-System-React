import React from 'react'

const Attendance = () => {
//! HAVE TO MAKE IT RESPONSIVE

  return (
    <div className='AttendanceBlock'>Attendance</div>
  )
}

export default Attendance